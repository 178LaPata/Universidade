var express = require('express');
var router = express.Router();
var Emd = require('../controllers/emd');

router.get('/emd', function(req, res) {
    Emd.list()
        .then(data => res.jsonp(data))
        .catch(erro => res.jsonp(erro))
});

module.exports = router;
