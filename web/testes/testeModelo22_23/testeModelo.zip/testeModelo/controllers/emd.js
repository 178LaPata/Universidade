const Emd = require('../models/emd');

module.exports.list = async () => {
    return await Emd
        .find()
        .exec();
}

module.exports.findById = id => {
    return Emd
        .findOne({ _id: id })
        .exec();
}

